#pragma once

typedef int Date;
double __declspec(dllexport) InvestAnnuity(Date, int, int, int, double);
